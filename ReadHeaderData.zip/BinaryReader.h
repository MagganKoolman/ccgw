#pragma once
class BinaryReader {
public :
	static void readFromBinary(GLuint &vao);
};